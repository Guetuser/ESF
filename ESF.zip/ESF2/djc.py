def genDDT(s):
#     print(s)
    sd = [[0 for i in range(16)] for i in range(16)]
    for i in range(16):#输入差分
        for j in range(16):
            sd[i][s[j]^s[j^i]] = sd[i][s[j]^s[j^i]]+1
    return sd

def getKS(s):
    sd = genDDT(s)
    KS=[]
    for i in range(len(sd)):
        temp = []
        for j in range((len(sd[i]))):
            if sd[i][j] !=0:
                temp.append(j)
        KS.append(temp)
    return KS

def getKSN(s):
    sd = genDDT(s)
    KSN = []
    for i in range(len(sd[0])):
        temp = []
        for j in range(len(sd)):
            if sd[j][i] != 0:
                temp.append(j)
        KSN.append(temp)
    return KSN

def KS_out(a,s):
    KS = getKS(s)
    count = []
    for i in range(len(a)):
        if a[i] == '-1':
            count.append(i)
    if len(count) == 4:
        return ['-1','-1','-1','-1']
    else:
        jishuqi = 0
        s_count = [0 for j in range(4)]
        for i in range(2**len(count)):
            b=a
            c = '{:04b}'.format(i)
            for j in range(len(count)):
                b[count[j]] = c[-j-1]
            b = int(''.join(b),2)
            
            for j in range(len(KS[b])):
                temp1 = '{:04b}'.format(KS[b][j])
                for z in range(4):
                    s_count[z] = s_count[z] + int(temp1[z])
                jishuqi = jishuqi +1
        for i in range(4):
            if s_count[i] == jishuqi :
                s_count[i] = '1'
            elif s_count[i] == 0:
                s_count[i] = '0'
            else:
                s_count[i] = '-1'
        return s_count
    
def KSN_out(a,s):
    KSN = getKSN(s)
    count = []
    for i in range(len(a)):
        if a[i] == '-1':
            count.append(i)
    if len(count) == 4:
        return ['-1','-1','-1','-1']
    else:
        jishuqi = 0
        s_count = [0 for j in range(4)]
        for i in range(2**len(count)):
            b=a
            c = '{:04b}'.format(i)
            
            for j in range(len(count)):
                b[count[j]] = c[-j-1]
            b = int(''.join(b),2)

            for j in range(len(KSN[b])):
                temp1 = '{:04b}'.format(KSN[b][j])
                for z in range(4):
                    s_count[z] = s_count[z] + int(temp1[z])
                jishuqi = jishuqi + 1
        for i in range(4):
            if s_count[i] == jishuqi:
                s_count[i] = '1'
            elif s_count[i] == 0:
                s_count[i] = '0'
            else:
                s_count[i] = '-1'
        return s_count
    
def P_model(a):
    p = [0, 8, 16, 24, 1, 9, 17, 25, 2, 10, 18, 26, 3, 11, 19, 27, 4, 12, 20, 28, 5, 13, 21, 29, 6, 14, 22, 30, 7, 15, 23, 31]
    b=[0 for i in range(32)]
    for i in p:
        b[p[i]] = a[i]
    return b

def PN_model(a):
    p = [0, 8, 16, 24, 1, 9, 17, 25, 2, 10, 18, 26, 3, 11, 19, 27, 4, 12, 20, 28, 5, 13, 21, 29, 6, 14, 22, 30, 7, 15, 23, 31]
    b=[]
    for i in p:
        b.append(a[i])
    return b

def KS_out_32(a,s):
    b=['0'for i in range(32)]
    for i in range(8):
        b[4*i:4*i+4] = KS_out(a[4*i:4*i+4],s[7-i])
    return b

def KSN_out_32(a,s):
    b=['0'for i in range(32)]
    for i in range(8):
        b[4*i:4*i+4] = KSN_out(a[4*i:4*i+4],s[7-i])
    print(b)
    return b

def cha_xor(a,b):
    if a == '-1' or b == '-1':
        return '-1'
    else:
        return str(int(a)^int(b))
    
def xor_32(a,b):
    c = []
    for i in range(32):
        c.append(cha_xor(a[i],b[i]))
    return c

def loop_7(a):
    temp = [0 for i in range(32)]
    for i in range(32):
        temp[i] = a[(i+7)%32]
    return temp

def loopN_7(a):
    temp = [0 for i in range(32)]
    for i in range(32):
        temp[i] = a[(i-7)%32]
    return temp

def xiangshang(a):
    s = [[3,8,0xf,1,0xa,6,5,0xb,0xe,0xd,4,2,7,0,9,0xc],
         [0xf,0xc,2,7,9,0,5,0xa,1,0xb,0xe,8,6,0xd,3,4],
         [8,6,7,9,3,0xc,0xa,0xf,0xd,1,0xe,4,0,0xb,5,2],
         [0,0xf,0xb,8,0xc,9,6,3,0xd,1,2,4,0xa,7,5,0xe],
         [1,0xf,8,3,0xc,0,0xb,6,2,5,4,0xa,9,0xe,7,0xd],
         [0xf,5,2,0xb,4,0xa,9,0xc,0,3,0xe,8,0xd,6,7,1],
         [7,2,0xc,5,8,4,6,0xb,0xe,9,1,0xf,0xd,3,0xa,0],
         [1,0xd,0xf,0,0xe,8,2,0xb,7,4,0xc,0xa,9,3,5,6]]
    temp = []
    temp1 = []
    left = a[0:32]
    right = a[32:64]
    temp.append(a)
    k = 0
    
    while k == 0 :
        temp1 = left
        left = KS_out_32(left,s)
#         print('s盒之后',left)
        left = P_model(left)
#         print('线性之后',left)
        left = xor_32(left,right)
        left = loopN_7(left)
#         left = loopN_7(xor_32(PN_model(KSN_out_32(left,s)),right))
        right = temp1
        temp.append(left+right)
        count = 0
        for i in left:
            if i == '-1':
                count = count+1
        if count == len(left):
            k = 1 
    return temp

def xiangxia(a):
    s = [[3,8,0xf,1,0xa,6,5,0xb,0xe,0xd,4,2,7,0,9,0xc],
         [0xf,0xc,2,7,9,0,5,0xa,1,0xb,0xe,8,6,0xd,3,4],
         [8,6,7,9,3,0xc,0xa,0xf,0xd,1,0xe,4,0,0xb,5,2],
         [0,0xf,0xb,8,0xc,9,6,3,0xd,1,2,4,0xa,7,5,0xe],
         [1,0xf,8,3,0xc,0,0xb,6,2,5,4,0xa,9,0xe,7,0xd],
         [0xf,5,2,0xb,4,0xa,9,0xc,0,3,0xe,8,0xd,6,7,1],
         [7,2,0xc,5,8,4,6,0xb,0xe,9,1,0xf,0xd,3,0xa,0],
         [1,0xd,0xf,0,0xe,8,2,0xb,7,4,0xc,0xa,9,3,5,6]]
    temp = []
    temp1 = []
    left = a[0:32]
    right = a[32:64]
    temp.append(a)
    k = 0
    
    while k == 0:
        temp1 = right
        right = KS_out_32(right,s)
        right = P_model(right)
        left = loop_7(left)
        right = xor_32(left,right)
#         right = xor_32(loop_7(left),P_model(KS_out_32(right,s)))
        left = temp1
        temp.append(left+right)
        count = 0
        for i in right:
            if i == '-1':
                count = count+1
        if count == len(right):
            k = 1
    return temp

def shuchu(a):
    b = []
    for i in range(len(a)):
        for j in range(len(a[i])):
            if a[i][j] == '-1':
                a[i][j] = '*'
#             if j%4 == 0:
#                 a[i][j] =' ' + a[i][j]
        b.append(''.join(a[i]))
    return b
    
def key_find_shang(shang):
    test = '{:064b}'.format(shang)
    test1 = []
    for i in range(len(test)):
        test1.append(test[i])
    a = xiangshang(test1)
    a = shuchu(a)
    return a

def key_find_xia(xia):
    test = '{:064b}'.format(xia)
    test1=[]
    for i in range(len(test)):
        test1.append(test[i])
    a = xiangxia(test1)
    a = shuchu(a)
    return a

##掐头去尾找密钥
def return_key_find_shang(shang):
    jishu = 0
    temp = key_find_shang(shang)
    key_bit = dict()
    for i in temp[1:]:
        key_bit[jishu] = []
        for j in range((len(i)//2)//4):
            if i[4*j+32:4*j+4+32] != '0000':
                key = []
                for k in range(4):
                    key.append(4*j+k)
                key_bit[jishu].append(key)
        jishu = jishu +1
    return key_bit
                
def return_key_find_xia(xia):
    jishu = 0
    temp = key_find_xia(xia)
    key_bit = dict()
    for i in temp[:-1]:
        key_bit[jishu] = []
        for j in range((len(i)//2)//4):
            if i[4*j+32:4*j+4+32] != '0000':
                key = []
                for k in range(4):
                    key.append(4*j+k)
                key_bit[jishu].append(key)
        jishu = jishu +1
    return key_bit

# temp1 = return_key_find_shang(2**31)
# temp2 = return_key_find_xia(8)
# # temp2 = return_key_find_xia(int('0001000000000000000000000000000000000000000000000000000000000000',2))
# for i in temp1:
#     print(i)
#     print(temp1[i])
# print()
# for i in temp2:
#     print(i)
#     print(temp2[i])
def s1(r,s_seat1,loop):
    p=[]
    for j in range(4):
        p.append(f'k_{r}_{((s_seat1-loop)+j)%80}')
    q=[]
    for j in range(4):
        q.append(f'k_{r+1}_{s_seat1+j}')
    pi = ','.join(p)
    pi = pi+' => '
    pi_r=''
    for j in range(4):
        pi_r = pi_r+pi+q[j]+'\n'
    
    qi = ','.join(q)
    qi = qi+' => '
    qi_r=''
    for j in range(4):
        qi_r = qi_r+qi+p[j]+'\n'
    return pi_r+qi_r
#     f.write(pi_r+qi_r)

def s2(r,s_seat2,loop):
    p=[]
    for j in range(4):
        p.append(f'k_{r}_{((s_seat2-loop)+j)%80}')
    q=[]
    for j in range(4):
        q.append(f'k_{r+1}_{s_seat2+j}')
    pi = ','.join(p)
    pi = pi+' => '
    pi_r=''
    for j in range(4):
        pi_r = pi_r+pi+q[j]+'\n'
    
    qi = ','.join(q)
    qi = qi+' => '
    qi_r=''
    for j in range(4):
        qi_r = qi_r+qi+p[j]+'\n'
    return pi_r+qi_r
#     f.write(pi_r+qi_r)

# def algebraic_relations(f,r,j):
#     p = []
#     q = []
#     for i in range(72):
#         p.append(f'k_{r}_{(i-j)%80}')
#         q.append(f'k_{r+1}_{i}')
#     for i in range(72):
#         temp = p[i]+' + '+q[i]+'\n'
#         f.write(temp)

def equal_relations(r,s_seat1,s_seat2,loop):
    p = []
    q = []
    temp = ''
#     for i in range((76-s_seat2)%80,(76-s_seat1)%80):
    for i in range(s_seat2):
        p.append(f'k_{r}_{(i-loop)%80}')
        q.append(f'k_{r+1}_{i}')
    for i in range(s_seat2+4,s_seat1):
        p.append(f'k_{r}_{(i-loop)%80}')
        q.append(f'k_{r+1}_{i}')
    for i in range(s_seat1+4,80):
        p.append(f'k_{r}_{(i-loop)%80}')
        q.append(f'k_{r+1}_{i}')
    for i in range(len(p)):
        temp = temp + p[i]+' , '+q[i]+'\n'
    return temp      

def generate_guanxi_keys_schedule(filepath,r,s_seat1,s_seat2,loop,shang,xia):
    c = ''
    with open(filepath,'w') as f :
        c = c + (f'#ESF_kb {r} Rounds\n')
        c = c + ('connection relations\n')
        for i in range(r):
            c = c + s1(i,s_seat1,loop)
            c = c + s2(i,s_seat2,loop)
    #     f.write('algebraic relations\n')
    #     for i in range(14):
    #         algebraic_relations(f,i)
        c = c + ('equal relations\n')
        for i in range(r):
            c = c + equal_relations(i,s_seat1,s_seat2,loop)
        c = c + ('target\n')
        for i in range(len(shang)):
            for j in shang[len(shang)-i-1]:
                for k in j:
                    c = c + (f'k_{i}_{80-k-1}\n')
        for i in xia:
            for j in xia[i]:
                for k in j:
                    c = c + (f'k_{len(shang)+9+i}_{80-k-1}\n')
#         for i in range(0,4):
#             f.write(f'k_0_{80-i-1}\n')
#         for i in range(8,12):
#             f.write(f'k_0_{80-i-1}\n')
#         for i in range(16,20):
#             f.write(f'k_0_{80-i-1}\n')
#         for i in range(24,28):
#             f.write(f'k_0_{80-i-1}\n')
#         for i in range(4,8):
#             f.write(f'k_1_{80-i-1}\n')
#         for i in range(24,28):
#             f.write(f'k_12_{80-i-1}\n')
#         for i in range(4,8):
#             f.write(f'k_13_{80-i-1}\n')
#         for i in range(12,16):
#             f.write(f'k_13_{80-i-1}\n')
#         for i in range(20,24):
#             f.write(f'k_13_{80-i-1}\n')
#         for i in range(28,32):
#             f.write(f'k_13_{80-i-1}\n')
#         for i in range(32):
#             f.write(f'k_14_{80-i-1}\n')
        c = c + ('end\n')
        f.write(c)
        
import os
import re
import sys
import string
import random
from collections import namedtuple
from subprocess import call
from config import PATH_SAGE
from config import TEMP_DIR
import time
from datetime import datetime

def ordered_set(seq):
    """
    This function eliminates duplicated elements in a given list, 
    and keeping the order of appearance unchanged, 
    returns a list in which each elements appears only once
    """

    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]

def get_equal_equation(path):
    
    contents = None
    try:
        if os.path.isfile(path):
            with open(path, 'r') as fileobj:
                contents = fileobj.read()
    except (TypeError, ValueError):
        pass
    
    contents = contents.strip()
    problem_name = find_problem_name(contents)
    sections = split_contents_by_sections(remove_comments(contents))
    
    equal_relations = sections.get('equal relations', '')
    equal_equations_file = os.path.join(TEMP_DIR, 'equal_equations.txt')
    if equal_relations != '':   
        with open(equal_equations_file, 'w') as equations_file:
            equations_file.write(equal_relations)
    print(equal_equations_file)

def get_algebraic_equation(path):

    contents = None
    try:
        if os.path.isfile(path):
            with open(path, 'r') as fileobj:
                contents = fileobj.read()
    except (TypeError, ValueError):
        pass
    
    contents = contents.strip()
    problem_name = find_problem_name(contents)
    sections = split_contents_by_sections(remove_comments(contents))
    
    algebraic_relations = sections.get('algebraic relations', '')
    algebraic_equations_file = os.path.join(TEMP_DIR, 'algebraic_equations.txt')
    if algebraic_relations != '':   
        with open(algebraic_equations_file, 'w') as equations_file:
            equations_file.write(algebraic_relations)
    print(algebraic_equations_file)


def read_relation_file(path, preprocess=1, D=2, log=0):
    """
    Reads a relation file in GD format and parses it into a systems of connection relations
    """

#     rnd_string_tmp = '%030x' % random.randrange(16**30)
    contents = None
    try:
        if os.path.isfile(path):
            with open(path, 'r') as fileobj:
                contents = fileobj.read()
    except (TypeError, ValueError):
        pass

    contents = contents.strip()
    problem_name = find_problem_name(contents)
    sections = split_contents_by_sections(remove_comments(contents))

    connection_relations = sections.get('connection relations', '')
    algebraic_relations = sections.get('algebraic relations', '')
    equal_relations = sections.get('equal relations','')
#     print('aaaaaa',equal_relations)
    variables = []
    if equal_relations != '':
        equal_relations,variables1 = parse_equal_relation(equal_relations)
#         with open ('equal.txt','w') as fealiejf:
#             for i in equal_relations:
#                 cwenben = ', '.join(i)+'\n'
#                 fealiejf.write(cwenben)
        variables.extend(variables1)
#     print('equal de bianliang:',variables1)
#     print()
    
#     print('rongru zong',variables)
#     algebraic_equations_file = os.path.join(TEMP_DIR, 'algebraic_equations_%s.txt' % rnd_string_tmp)
    if algebraic_relations != '' and preprocess == 1:   
#         with open(algebraic_equations_file, 'w') as equations_file:
#             equations_file.write(algebraic_relations)
#         starting_time = time.time()
#         print('Preprocessing phase was started - %s' % datetime.now())
        macaulay_basis_file = os.path.join(TEMP_DIR, 'macaulay_basis.txt')
#         sage_process = call(["-python3", os.path.join("core", "macaulay.py"), 
#                              "-i", algebraic_equations_file,
#                              "-o", macaulay_basis_file,
#                              "-t", "degrevlex",
#                              "-D", str(D)],shell = 'Ture')
#         print(sage_process)
#         elapsed_time = time.time() - starting_time
#         print('Preprocessing phase was finished after %0.4f seconds' % elapsed_time)
        try:
            with open(macaulay_basis_file, 'r') as groebner_basis_file:
                groebner_basis = groebner_basis_file.read()
                temp = groebner_basis_file.readlines()[0:-2]
        except IOError:
            print(macaulay_basis_file + ' is not accessible!')
            sys.exit()
        algebraic_relations += '\n' + groebner_basis
        # algebraic_relations = groebner_basis
        if connection_relations == '':
            connection_relations = algebraic_relations_to_connection_relations(algebraic_relations.split('\n'))
        else:
            connection_relations += '\n' + algebraic_relations_to_connection_relations(algebraic_relations.split('\n'))
    elif algebraic_relations != '' and preprocess == 0:
        if connection_relations == '':
            connection_relations = algebraic_relations_to_connection_relations(algebraic_relations.split('\n'))
        else:
            connection_relations += '\n' + algebraic_relations_to_connection_relations(algebraic_relations.split('\n'))
    symmetric_relations, implication_relations, variables2 = parse_connection_relations(connection_relations)
    variables.extend(variables2)
#     print(variables2)
#     print()
#     print(variables)
    variables = ordered_set(variables)
    known_variables = sections.get('known', [])
    if known_variables != []:
        known_variables = known_variables.split('\n')
    known_variables.extend([rel[0] for rel in symmetric_relations if len(rel) == 1])
    known_variables = ordered_set(known_variables)
    symmetric_relations = [rel for rel in symmetric_relations if len(rel) != 1]
    target_variables = sections.get('target', [])
    if target_variables != []:
        target_variables = target_variables.split('\n')
    else:
        target_variables = variables
    weights_section = sections.get('weights', [])
    target_weights = None
    if weights_section != []:
        target_weights = dict()
        weights_section = weights_section.split('\n')        
        for element in weights_section:
            var, weight = element.split(' ')
            target_weights[var] = int(weight)
    notguessed_variables = sections.get('not guessed', [])
    if notguessed_variables != []:
        notguessed_variables = notguessed_variables.split('\n')
    parsed_data = {'problem_name': problem_name,
                   'variables': variables,
                   'known_variables': known_variables,
                   'target_variables': target_variables,
                   'target_weights' : target_weights,
                   'notguessed_variables': notguessed_variables,
                   'symmetric_relations': symmetric_relations,
                   'implication_relations': implication_relations,
                   'equal_relations': equal_relations}
#     if log == 0 and preprocess == 1:
#         os.remove(algebraic_equations_file)
#         os.remove(macaulay_basis_file)
    return parsed_data


def find_problem_name(contents):
    """
    Find the name of the problem by reading the first comments if it exists.
    If no comments are found 'gdproblem' is used by default.
    """

    pattern = re.compile(r"(?<=#).*?\n", re.DOTALL)
    match = pattern.search(contents)
    if match:
        return match.group().strip()
    return 'gdproblem'


def split_contents_by_sections(contents):
    """
    Split a relation file into multiple sections
    It searches for the following keywords and split the contents by section
    'connection relations', 'algebraic relations', 'known', 'target', 'not guessed'
    Raises ValueError when the given contents is not in a valid GD format    
    """

    keywords = {
        'connection relations': ('connection relation', 'connection relations'),
        'algebraic relations': ('algebraic relation', 'algebraic relations'),
        'equal relations': ('equal relation', 'equal relations'),
        'known': ('known variables', 'known'),
        'target': ('target variables', 'target'),
        'not guessed': ('not guessed', ),
        'weights': ('weights', 'weight', ),
        'end': ('end', )
    }
    sections = []
    Section = namedtuple('Section', ('name', 'keyword_start', 'keyword_end'))

    for section_name, keywords in keywords.items():
        try:
            match, keyword_start, keyword_end = search_keywords(
                contents, keywords)
            sections.append(Section(section_name.lower(),
                                    keyword_start, keyword_end))
        except AttributeError:
            pass
    # sort by the start index of the section
    sections.sort(key=lambda x: x.keyword_start)

    if sections[-1].name != 'end':
        raise ValueError('File must end with an "end" keyword')

    parsed_sections = {}

    for i in range(len(sections) - 1):
        section = sections[i]
        next_section = sections[i + 1]
        parsed_sections[section.name] = contents[section.keyword_end:next_section.keyword_start].strip()

    return parsed_sections

def search_keywords(contents, keywords):
    """
    Search multiple keywords in a given contents case insensitively, and return the first match
    Raises ValueError when none of the keywords is found in the contents
    """

    sense_pattern = re.compile(
        '|'.join(rf'\b{re.escape(keyword)}\b' for keyword in keywords), re.IGNORECASE)
    match = sense_pattern.search(contents)
    return match.group(), match.start(), match.end()

def remove_comments(contents):
    """
    Remove the comments from the contents
    """
    
    contents = re.sub(re.compile(r"#.*?\n", re.DOTALL), "",
                      contents)  # remove all occurrences of #COMMENT from line
    return contents

def parse_equal_relation(equal_relations):
    dengjia_relations = []
    variables = []
    equal_relations = equal_relations.replace(' ','')
    equal_relations = equal_relations.split('\n')
    for i in range(len(equal_relations)):
        equal_relations[i] = equal_relations[i].split(',')
    
    remaining_elements = set()
    for lst in equal_relations:
        intersection = set(lst) & remaining_elements
        if intersection:
            for cl in dengjia_relations:
                if intersection & set(cl):
                    cl.extend(lst)
                    remaining_elements |= set(lst)
                    break
        else:
            dengjia_relations.append(lst)
            remaining_elements |= set(lst)
            
    for i in range(len(dengjia_relations)):
        dengjia_relations[i] = list(ordered_set(dengjia_relations[i]))
        variables.extend(dengjia_relations[i])
    variables = ordered_set(variables)
    return dengjia_relations,variables

def parse_connection_relations(connection_relations):
    variables = []
    symmetric_relations = []
    implication_relations = []
    connection_relations = connection_relations.replace(' ', '')
    connection_relations = connection_relations.split('\n')
    for rel in connection_relations:
        # Extract implication relations
        if '=>' in rel:
            rel = re.split(',|=>', rel)
            implication_relations.append(rel)
        # Extract symmetric relations
        else:
            rel = rel.split(',')
            symmetric_relations.append(rel)
        variables.extend(rel)
    variables = ordered_set(variables)
    return symmetric_relations, implication_relations, variables


def random_prefix_generator(N):
    """
    Generate a random string of length N
    """

    return ''.join(random.choice(string.ascii_uppercase) for _ in range(N))

def get_variables_from_monomial(monomial):
    """
    It is fed by a non-constant monomial like x*y*z and 
    returns a list consisting of given monomial's
    variables. which in this case are: ['x', 'y', 'z']
    """
    assert(not monomial.isdigit())
    temp = monomial.split('*')
    temp.sort()
    return temp

def get_variables_from_list_of_monomials(list_of_monomials):
    """
    It is fed by a list of monomials and returns the variables 
    which are used in the given monomials
    """
    vars = set()
    for monomial in list_of_monomials:
        vars = vars.union(get_variables_from_monomial(monomial))
    temp = list(vars)
    temp.sort()
    return temp

def get_monomials_from_polynomial(polynomial):
    """
    It is fed by a polynomial, and returns its monomials
    """

    monomials = polynomial.split('+')
    if '1' in monomials:
        monomials.remove('1')
    if '0' in monomials:
        monomials.remove('0')
    return list(set(monomials))

def get_monomials_from_list_of_polys(polys):
    """
    It is fed by a list of polynomials and returns
    all of the monomials which are used in the given 
    polynomials
    """

    monomials = set()
    for poly in polys:
        monos = set(get_monomials_from_polynomial(poly))
        monomials = monomials.union(monos)
    return list(monomials)

def degree_of_monomial(monomial):
    """
    Returns the degree of the given monomial
    """

    vars = get_variables_from_monomial(monomial)
    return len(vars)

def algebraic_relations_to_connection_relations(algebraic_relations):
    """
    Generate the connection relations derived from the given algebraic relations by introducing new variables
    It currently work for boolean polynomial relations merely
    """

    connection_relations = []
    if algebraic_relations[-1] == '':
        algebraic_relations[-1:] = []
    algebraic_relations = [poly.replace(' ', '') for poly in algebraic_relations]
    all_monomials = get_monomials_from_list_of_polys(algebraic_relations)
    algebraic_variables = get_variables_from_list_of_monomials(all_monomials)
    dummy_vars_prefix = random_prefix_generator(4)
    substitution_dictionary = dict()
    for monomial in all_monomials:
        if degree_of_monomial(monomial) >= 2:
            monomial_variables = get_variables_from_monomial(monomial)
            var_indices = [algebraic_variables.index(
                x) for x in monomial_variables]
            var_indices = list(map(str, var_indices))
            dummy_var = "{0}{1}".format(
                dummy_vars_prefix, "".join(var_indices))
            if dummy_var not in substitution_dictionary.values():
                connection_relations.append("{0}=>{1}".format(
                    ",".join(monomial_variables), dummy_var))
            substitution_dictionary[monomial] = dummy_var

    for poly in algebraic_relations:
        linearized_relation = [substitution_dictionary.get(term, term) for term in poly.split("+")]
        if '1' in linearized_relation:
            linearized_relation.remove('1')
        if '0' in linearized_relation:
            linearized_relation.remove('0')
        connection_relations.append(",".join(linearized_relation))
    return "\n".join(connection_relations)

# from core.parsesolution import parse_solver_solution
from gurobipy import *
# from core.inputparser import read_relation_file
import os
import time
import random
from core.parsesolution import parse_solver_solution
# from core.graphdrawer import draw_graph
# from config import TEMP_DIR

class ReduceGDtoMILP:
    """
    ReduceGDtoMILP-version4-kb
    This class reduces the guess-and-determine attack and 
    key-bridging to an MILP problem, and then solves it via Gurobi
    Created by Hosein Hadipour
    version4-kb
    July 13, 2020
    mod 0: Maximization
    mod 1: Minimization
    max_guess:  The number of guessed variables in mod 0,
                and an upper bound for the number of guessed variables in mod 1
    max_steps:  Number of state copies 
    """

    count = 0

    def __init__(self, inputfile_name='', outputfile_name='output', max_guess=0, max_steps=0, direction='min',\
        tikz=0, preprocess=1, D=2, dglayout="dot", log=0):
        self.inputfile_name = inputfile_name
        self.rnd_string_tmp = '%030x' % random.randrange(16**30)        
        self.output_dir = outputfile_name
        self.max_guess = max_guess
        self.max_steps = max_steps
        self.direction = direction
        self.dglayout = dglayout
        self.log = log
        ###############################
        # Read and parse the input file
        parsed_data = read_relation_file(self.inputfile_name, preprocess, D)
        self.problem_name = parsed_data['problem_name']
        self.variables = parsed_data['variables']
        self.known_variables = parsed_data['known_variables']
        self.target_variables = parsed_data['target_variables']
        self.target_weights = parsed_data['target_weights']
        self.notguessed_variables = parsed_data['notguessed_variables']
        self.symmetric_relations = parsed_data['symmetric_relations']
        self.implication_relations = parsed_data['implication_relations']
        self.equal_relations = parsed_data['equal_relations']
        self.num_of_relations = len(
            self.symmetric_relations) + len(self.implication_relations) + len(self.equal_relations)
        self.num_of_vars = len(self.variables)
        ###############################
        if self.max_guess is None:
            self.max_guess = len(self.target_variables)
            print('The number of guessed variables is set to be at most %d' % self.max_guess)
        self.lpfile_name = 'gai_milp_mg%d_ms%d_%s_%s.lp' % (
                            self.max_guess,\
                            max_steps, direction, self.rnd_string_tmp)
        self.deductions = self.generate_possible_deductions()
        self.equal_deductions = self.generate_possible_equal_deductions()
        # milp_variables is initialized to the variables corresponding to the initial state variables
        self.milp_variables = ['%s_0' % v for v in self.variables]
        self.time_limit = -1
        self.tikz = tikz

    def ordered_set(self, seq):
        """
        This method eliminates duplicated elements in a given list, 
        and returns a list in which each elements appears only once
        """

        seen = set()
        seen_add = seen.add
        return [x for x in seq if not (x in seen or seen_add(x))]

    def generate_possible_equal_deductions(self):
        possible_deductions = {}
        for v in self.variables:
            possible_deductions[v] = []
            for rel in self.equal_relations:
                if v in rel:
                    temp = rel.copy()
                    temp.remove(v)
                    possible_deductions[v].append(temp)
        return possible_deductions
    
    def generate_possible_deductions(self):
        """
        This method generates all possible deductions 
        Core idea of information propagation: 
            If there is a relation in which all terms are known except one, 
            then the value of the last term can be determined as well. 
        """

        possible_deductions = {}
        for v in self.variables:
            possible_deductions[v] = [[v]]
            for rel in self.symmetric_relations:
                if v in rel:
                    temp = rel.copy()
                    temp.remove(v)
                    possible_deductions[v].append(temp)
            for rel in self.implication_relations:
                if v == rel[-1]:
                    temp = rel.copy()
                    temp.remove(v)
                    possible_deductions[v].append(temp)
#             for rel in self.equal_relations:
#                 if v in rel:
#                     temp = rel.copy()
#                     temp.remove(v)
#                     possible_deductions[v].append(temp)
        return possible_deductions

    def generate_objective_function(self):
        """
        This method generates the objective function of the MILP problem
        """

        if self.direction == 'max':
            objective_function = 'Maximize\n'
            final_state = ['%s_%d' % (v, self.max_steps)
                           for v in self.target_variables]
            objective_function += ' + '.join(final_state)
        elif self.direction == 'min':
            objective_function = 'Minimize\n'
            unknown_init_state_vars = [v for v in self.variables if v not in self.known_variables]
            if self.target_weights != None:
                print("target_weights != None")
                wights = [self.target_weights.get(v, 1) for v in unknown_init_state_vars]
                weighted_init_state = zip(wights, unknown_init_state_vars)
                objective_list = ['%d %s_%d' % (w, v, 0) for (w, v) in weighted_init_state]                
            else:
                objective_list = ['%s_%d' % (v, 0) for v in self.target_variables]
            objective_function += ' + '.join(objective_list)
        objective_function += '\n'
        return objective_function

    def generate_initial_conditions(self):
        """
        This method generates the initial constraints consisting of 
        constrains corresponding to the maximum number of guessed variables, and 
        number of known variables in the initial state
        """

        initial_constraints = 'Subject To\n'

        unknown_vars = ['%s' % v for v in self.variables if v not in self.known_variables]
        unknown_init_state_vars = ['%s_0' % v for v in unknown_vars]
        first_state_target_vars = ['%s_0' % v for v in self.target_variables]
        not_target_vars = ['%s_0' % v for v in self.variables if v not in self.target_variables]
        if self.target_weights != None:
            LHS1 = ['%d %s_0' % (self.target_weights[v], v) for v in unknown_vars]
            LHS1 = ' + '.join(LHS1)
        else:
            LHS1 = ' + '.join(first_state_target_vars)
        RHS1 = self.max_guess
        final_state_target_vars = ['%s_%d' % (
            v, self.max_steps) for v in self.target_variables]
        LHS2 = ' + '.join(final_state_target_vars)
        RHS2 = len(final_state_target_vars)
        
        LHS3 = ' + '.join(not_target_vars)
        RHS3 = 0

        if self.direction == 'max':
            # initial_constraints += '%s = %d\n' % (LHS1, RHS1)
            initial_constraints += '%s <= %d\n' % (LHS1, RHS1)
        elif self.direction == 'min':
            initial_constraints += '%s <= %d\n' % (LHS1, RHS1)
            initial_constraints += '%s = %d\n' % (LHS2, RHS2)          
            initial_constraints += '%s = %d\n' % (LHS3, RHS3)

        for v in self.known_variables:
            if v != '':
                initial_constraints += '%s_0 = 1\n' % v

        # Limit the notguessed variables to be equal to 0 in the first step of knowledge propagation
        for v in self.notguessed_variables:
            if v != '':                
                initial_constraints += '%s_0 = 0;\n' % v        
        return initial_constraints
    

    def generate_milp_constraints(self):
        """
        This method generates the milp constraints corresponding to the 
        obtained deductions.
        """

        milp_constraints = ''
        for step in range(self.max_steps):
            for v in self.variables:
                v_old = '%s_%d' % (v, step)
                v_new = '%s_%d' % (v, step + 1)
                tau1 = len(self.deductions[v])
                tau2 = len(self.equal_deductions[v])
                tau = tau1 + tau2
                v_path_variables = ['%s_%d_%d' %
                                    (v, step + 1, i) for i in range(tau)]
                self.milp_variables.extend([v_new] + v_path_variables)
                #####################################-State variable constraints-#####################################
                ######################################################################################################
                ######################################################################################################
                LHS = ' + '.join(v_path_variables)
                milp_constraints += '\ Constraints corresponding to the state variable %s:\n' % v_new
                if tau == 1:
                    milp_constraints += '%s - %s = 0\n' % (v_new, LHS)
                else:
                    milp_constraints += '-2 %s + %s >= -1\n' % (v_new, LHS)
                    milp_constraints += '%d %s - %s >= 0\n' % (
                        tau, v_new, LHS.replace('+', '-'))
                #####################################-Path variable constraints-######################################
                ######################################################################################################
                ######################################################################################################
                for i in range(tau1):
                    v_connected_variables = ['%s_%d' % (
                        var, step) for var in self.deductions[v][i]]
                    LHS = ' - '.join(v_connected_variables)
                    kapa = len(v_connected_variables)
                    milp_constraints += '\ Constraints corresponding to the path variable %s:\n' % v_path_variables[i]
                    if kapa == 1:
                        milp_constraints += '%s - %s = 0\n' % (
                            v_path_variables[i], LHS)
                    else:
                        milp_constraints += '%s - %s >= %d\n' % (
                            v_path_variables[i], LHS, 1 - kapa)
                        milp_constraints += '-%d %s + %s >= 0\n' % (
                            kapa, v_path_variables[i], LHS.replace('-', '+'))
                #####################################-Path variable constraints-######################################
                ######################################################################################################
                ######################################################################################################
#                 for i in range(tau // 2, tau):
#                     v_connected_variables = ['%s_%d' % (
#                         var, step) for var in self.deductions[v][i]]
#                     LHS = ' - '.join(v_connected_variables)
#                     kapa = len(v_connected_variables)
#                     milp_constraints += '\ Constraints corresponding to AAAA the path variable %s:\n' % v_path_variables[i]
#                     if kapa == 1:
#                         milp_constraints += '%s - %s = 0\n' % (
#                             v_path_variables[i], LHS)
#                     else:
#                         milp_constraints += '%s - %s >= %d\n' % (
#                             v_path_variables[i], LHS, 1 - kapa)
#                         milp_constraints += '-%d %s + %s >= 0\n' % (
#                             kapa, v_path_variables[i], LHS.replace('-', '+'))
                ##################################-equal Path variable constraints-###################################
                ######################################################################################################
                ######################################################################################################
                for i in range(tau1, tau):
                    v_equal_variables = ['%s_%d' % (
                        var, step) for var in self.equal_deductions[v][i - tau1]]
                    LHS = ' + '.join(v_equal_variables)
                    kapa = len(v_equal_variables)
                    milp_constraints += '\ Constraints corresponding to the equal path variable %s:\n' % v_path_variables[i]
                    if kapa == 1:
                        milp_constraints += '%s - %s = 0\n' % (
                            v_path_variables[i], LHS)
                    else:
                        milp_constraints += '-2 %s + %s >= -1\n' % (
                            v_path_variables[i], LHS)
                        milp_constraints += '%d %s - %s >= 0\n' % (
                            kapa, v_path_variables[i], LHS.replace('+', '-'))
                ######################################################################################################
                ######################################################################################################
                ######################################################################################################
                # Given that the order of putting constraints into an LP file have a great impact on the performance of
                # Gurobi (and other CP solvers), user may want to change the order of constraints inside the generated
                # LP file in order to find a more suitable ordering. It is not known which odering might be the best from
                # the theoretical point of view in general. However, according to my experiences it may be better to put the connected
                # relations closer to each other. For example, change the order of the above blocks to see what impact it has
                # on the performance.
        return milp_constraints

    def declare_binary_variables(self):
        """
        This function declares the binary variables into the generated LP file
        """

        constraints = 'Binary\n'
        for v in self.milp_variables:
            constraints += '%s\n' % v
        return constraints

    def make_model(self):
        """
        This method makes the MILP model, and then write it into an LP file
        """

        print('Generating the MILP model ...')
        start_time = time.time()
        lp_str = self.generate_objective_function()
        lp_str += self.generate_initial_conditions()
        lp_str += self.generate_milp_constraints()
        lp_str += self.declare_binary_variables()
        lp_str += 'End\n'
        lp_file_path = os.path.join('lp', self.lpfile_name)
        elapsed_time = time.time() - start_time
        with open(lp_file_path, 'w') as lpfile:
                lpfile.write(lp_str) 
        if self.log == 1:
            print('MILP model was generated, and written into %s after %0.2f seconds' % (
                lp_file_path, elapsed_time))
        else:
            print('MILP model was generated after %0.2f seconds' % elapsed_time)

    def parse_and_write_solution(self):
        """
        This method parses the obtained soltuion (If MILP model is feasible), 
        and derives the determination flow such that user can simply find
        how the target variables are determined
        """
        
        self.vertices = []
        self.edges = []
        
        separator_line = ''.join(['#']*60)
        output_buffer = ''
        output_buffer += 'Number of Relations: %d\n' % self.num_of_relations
        output_buffer += 'Number of variables: %d\n' % self.num_of_vars
        output_buffer += 'Number of target variables: %d\n' % len(
            self.target_variables)
        output_buffer += 'Number of known variables: %d\n' % len(
            self.known_variables)
        output_buffer += 'Number of guessed variables: %d\n' % len(
            self.guessed_vars)
        output_buffer += 'Number of state copies (max_steps): %d\n' % self.max_steps
        output_buffer += 'An upper bound for the number of guessed variables given by user (max_guess): %d\n' % self.max_guess
        output_buffer += '%d out of %d state variables are known after %d state copies\n' % (
            self.final_info, self.num_of_vars, self.max_steps)
        output_buffer += separator_line
        output_buffer += '\nThe following %d variable(s) are guessed:\n%s\n' % (
            len(self.guessed_vars), ', '.join(self.guessed_vars))
        output_buffer += separator_line
        output_buffer += '\nThe following %d variable(s) are initially known:\n%s\n' % (
            len(self.known_variables), ', '.join(self.known_variables))
        output_buffer += separator_line
        output_buffer += '\nTarget variables:\n%s\n' % ', '.join(
            self.target_variables)

        output_buffer += separator_line
        output_buffer += '\nDetermination flow:\n'
        step = 0
        determined_target_variables = dict(
            zip(self.target_variables, [0]*(len(self.target_variables))))
        for v in self.known_variables + self.guessed_vars:
            determined_target_variables[v] = 1
        while step < self.max_steps + 1 and not(all(determined_target_variables.values())):
            sub_title = '\nState %d:\n' % step
            output_buffer += sub_title
            for rel in self.symmetric_relations:
                rel_known_vars = [
                    v for v in rel if self.solutions[step]['%s_%d' % (v, step)] == 1]
                rel_str = ', '.join(rel)
                if len(rel_known_vars) == (len(rel) - 1):
                    determined_var = list(set(rel) - set(rel_known_vars))
                    lhs = ', '.join(rel_known_vars)
                    rhs = ', '.join(determined_var)
                    self.vertices.append(rhs)
                    for vr in rel_known_vars:
                        self.vertices.append(vr)
                        self.edges.append((vr, rhs))
                    if determined_var[0] in self.target_variables:
                        determined_target_variables[determined_var[0]] = 1
                    output = '%s in symmetric relation [%s] are known: %s ===> %s' % (
                        lhs, rel_str, lhs, rhs) + '\n'
                    output_buffer += output
            
            for rel in self.equal_relations:
                rel_known_vars = [
                    v for v in rel if self.solutions[step]['%s_%d' % (v, step)] == 1]
                rel_str = ', '.join(rel)
                if len(rel_known_vars) >=1 :
                    determined_var = list(set(rel) - set(rel_known_vars))
                    lhs = ', '.join(rel_known_vars)
                    rhs = ', '.join(determined_var)
                    self.vertices.append(rhs)
                    for vr in rel_known_vars:
                        self.vertices.append(vr)
                        self.edges.append((vr, rhs))
                    if determined_var[0] in self.target_variables:
                        determined_target_variables[determined_var[0]] = 1
                    output = '%s in equal relation [%s] are known: %s ===> %s' % (
                        lhs, rel_str, lhs, rhs) + '\n'
                    output_buffer += output
            
            for rel in self.implication_relations:
                rel_known_vars = [
                    v for v in rel if self.solutions[step]['%s_%d' % (v, step)] == 1]
                rel_str = ', '.join(rel)
                if rel_known_vars == rel[0:-1]:
                    determined_var = [rel[-1]]
                    lhs = ', '.join(rel_known_vars)
                    rhs = ', '.join(determined_var)
                    self.vertices.append(rhs)
                    for vr in rel_known_vars:
                        self.vertices.append(vr)
                        self.edges.append((vr, rhs))
                    if determined_var[0] in self.target_variables:
                        determined_target_variables[determined_var[0]] = 1
                    output = '%s in implication relation [%s] are known: %s ===> %s' % (
                        lhs, rel_str, lhs, rhs) + '\n'
                    output_buffer += output
            output_buffer += separator_line
            step += 1
        self.finally_known = [v for v in self.variables if self.solutions[self.max_steps]['%s_%d' % (v, self.max_steps)] == 1]
        output_buffer += '\nThe following variables are known in final state:\n%s' % ', '.join(self.finally_known)
        with open(self.output_dir, 'w') as outputfile_obj:
            outputfile_obj.write(output_buffer)

    def solve_model(self):
        """
        This method uses Gurobi to solve the obtained MILP problem
        """
        lpfile_path = os.path.join('lp', self.lpfile_name)
        self.milp_model = read(lpfile_path)
        if self.log == 0:
            os.remove(lpfile_path)
        if self.time_limit != -1:
            self.milp_model.params.TimeLimit = self.time_limit
        # 0 (default: Gurobi strikes a balance between finding feasible solution and proving the optimality)
        self.milp_model.params.MIPFocus = 0
        # 1 (quickly find a feasible solution)
        # 2 (proving optimality is in priority)
        # 3 (focus on the best bound)
        self.milp_model.params.Threads = 0  # 0 (default value)
        self.milp_model.params.OutputFlag = 0  # 1 (default value)
#         self.milp_model.params.verbose = 0 #试一下不显示冗余

#         start_time = time.time()
        ##########################
        ##########################
        self.milp_model.optimize()
        ##########################
        ##########################
#         elapsed_time = time.time() - start_time
#         print('Solving process was finished after %0.2f seconds' % elapsed_time)

        if self.milp_model.Status == GRB.OPTIMAL or self.milp_model.Status == GRB.INTERRUPTED or self.milp_model.Status == GRB.TIME_LIMIT:
            if self.milp_model.SolCount == 0:
                print(
                    'No solution found! Perhaps, I need more time to solve this problem.')
                return
            self.objval = self.milp_model.objval
            self.solutions = [0]*(self.max_steps + 1)
            for step in range(self.max_steps + 1):
                state_vars = ['%s_%d' % (v, step) for v in self.variables]
                state_values = list(
                    map(lambda x: int(self.milp_model.getVarByName(x).Xn), state_vars))
                self.solutions[step] = dict(zip(state_vars, state_values))
            if self.milp_model.SolCount == 0:
                print('Sorry! There is no solution to be parsed.\nTry again please.')
                return
            else:
                if self.log == 1:
                    gurobi_solution_file_name = 'grbsol_mg%d_ms%d_%s.sol' % (
                        self.max_guess, self.max_steps, self.direction)
                    grb_solution_file_path = os.path.join(
                        TEMP_DIR, gurobi_solution_file_name)
                    self.milp_model.write(grb_solution_file_path)                    
#                 parse_solver_solution(self)
#                 draw_graph(self.vertices, self.edges, self.known_variables, self.guessed_vars,\
#                     self.output_dir, self.tikz, self.dglayout)
        elif self.milp_model.Status == GRB.INFEASIBLE:
            print('The obtained milp model is infeasible')
        else:
            print('Unknown error!')
        print(self.objval)
        print('--------------------------------------------------------------')
        return int(self.objval)
    
import multiprocessing

def aleifjadklf1(data,s_p,lujing,path1):
    jilu = []
    gai1 = []
    for i in range(len(data)//2):
        print(i,':')
        temp1 = data[2*i]
        temp2 = data[2*i+1]
        r = 9 + len(temp1) + len(temp2) - 1
        generate_guanxi_keys_schedule(path1,r,s_p[0],s_p[1],s_p[2],temp1,temp2)
        gdmilp = ReduceGDtoMILP(inputfile_name = path1,
                                outputfile_name = 'output',
                                max_guess=104,
                                max_steps=12,
                                direction='min')
        gdmilp.make_model()
        min_guess_num = gdmilp.solve_model()
        gai1.append(min_guess_num)
    tlujing = os.path.join(lujing,f'{s_p[0]}_{s_p[1]}_{s_p[2]}.txt')
    with open(tlujing,'w') as f:
        for i in gai1:
            f.write(f'{i} ')

if __name__ == "__main__":
    # 维持执行的进程总数为processes，当一个进程执行完毕后会添加新的进程进去
    pool = multiprocessing.Pool(9)
    path1 = []
    for i in range(9):
        path1.append(f'check{i}.txt')
    lujing = 'new_check'
    
    zong_s_p = [
        [72, 61, 77] ,
[72, 62, 4] ,
[73, 53, 54] ,
[73, 54, 29] ,
[73, 59, 2] ,
[73, 59, 3] ,
[73, 59, 4] ,
[73, 59, 5] ,
[73, 59, 6] ,
[73, 59, 7] ,
[73, 59, 8] ,
[73, 59, 9] ,
[73, 59, 10] ,
[73, 59, 11] ,
[73, 59, 12] ,
[73, 59, 13] ,
[73, 59, 14] ,
[73, 59, 15] ,
[73, 59, 16] ,
[73, 59, 17] ,
[73, 59, 18] ,
[73, 59, 19] ,
[73, 59, 20] ,
[73, 59, 21] ,
[73, 59, 22] ,
[73, 59, 23] ,
[73, 59, 24] ,
[73, 59, 25] ,
[73, 59, 26] ,
[73, 59, 27] ,
[73, 59, 28] ,
[73, 59, 29] ,
[73, 59, 30] ,
[73, 59, 31] ,
[73, 59, 32] ,
[73, 59, 33] ,
[73, 59, 34] ,
[73, 59, 35] ,
[73, 59, 36] ,
[73, 59, 37] ,
[73, 59, 38] ,
[73, 59, 39] ,
[73, 59, 40] ,
[73, 59, 41] ,
[73, 59, 42] ,
[73, 59, 43] ,
[73, 59, 44] ,
[73, 59, 45] ,
[73, 59, 46] ,
[73, 59, 47] ,
[73, 59, 48] ,
[73, 59, 49] ,
[73, 59, 50] ,
[73, 59, 51] ,
[73, 59, 52] ,
[73, 59, 53] ,
[73, 59, 54] ,
[73, 59, 55] ,
[73, 59, 56] ,
[73, 59, 57] ,
[73, 59, 58] ,
[73, 59, 59] ,
[73, 59, 60] ,
[73, 59, 61] ,
[73, 59, 62] ,
[73, 59, 63] ,
[73, 59, 64] ,
[73, 59, 65] ,
[73, 59, 66] ,
[73, 59, 67] ,
[73, 59, 68] ,
[73, 59, 69] ,
[73, 59, 70] ,
[73, 59, 71] ,
[73, 59, 72] ,
[73, 59, 73] ,
[73, 59, 74] ,
[73, 59, 75] ,
[73, 59, 76] ,
[73, 59, 77] ,
[73, 59, 78] ,
[73, 59, 79] ,
[73, 60, 1] ,
[73, 60, 2] ,
[73, 60, 3] ,
[73, 60, 4] ,
[73, 60, 5] ,
[73, 60, 6] ,
[73, 60, 7] ,
[73, 60, 8] ,
[73, 60, 9] ,
[73, 60, 10] ,
[73, 60, 11] ,
[73, 60, 12] ,
[73, 60, 13] ,
[73, 60, 14] ,
[73, 60, 15] ,
[73, 60, 16] ,
[73, 60, 17] ,
[73, 60, 18] ,
[73, 60, 19] ,
[73, 60, 20] ,
[73, 60, 21] ,
[73, 60, 22] ,
[73, 60, 23] ,
[73, 60, 24] ,
[73, 60, 25] ,
[73, 60, 26] ,
[73, 60, 27] ,
[73, 60, 28] ,
[73, 60, 29] ,
[73, 60, 30] ,
[73, 60, 31] ,
[73, 60, 32] ,
[73, 60, 33] ,
[73, 60, 34] ,
[73, 60, 35] ,
[73, 60, 36] ,
[73, 60, 37] ,
[73, 60, 38] ,
[73, 60, 39] ,
[73, 60, 40] ,
[73, 60, 41] ,
[73, 60, 42] ,
[73, 60, 43] ,
[73, 60, 44] ,
[73, 60, 45] ,
[73, 60, 46] ,
[73, 60, 47] ,
[73, 60, 48] ,
[73, 60, 49] ,
[73, 60, 50] ,
[73, 60, 51] ,
[73, 60, 52] ,
[73, 60, 53] ,
[73, 60, 54] ,
[73, 60, 55] ,
[73, 60, 56] ,
[73, 60, 57] ,
[73, 60, 58] ,
[73, 60, 59] ,
[73, 60, 60] ,
[73, 60, 61] ,
[73, 60, 62] ,
[73, 60, 63] ,
[73, 60, 64] ,
[73, 60, 65] ,
[73, 60, 66] ,
[73, 60, 67] ,
[73, 60, 68] ,
[73, 60, 69] ,
[73, 60, 70] ,
[73, 60, 71] ,
[73, 60, 72] ,
[73, 60, 73] ,
[73, 60, 74] ,
[73, 60, 75] ,
[73, 60, 76] ,
[73, 60, 77] ,
[73, 60, 78] ,
[73, 60, 79] ,
[73, 61, 1] ,
[73, 61, 2] ,
[73, 61, 3] ,
[73, 61, 4] ,
[73, 61, 5] ,
[73, 61, 6] ,
[73, 61, 7] ,
[73, 61, 8] ,
[73, 61, 9] ,
[73, 61, 10] ,
[73, 61, 11] ,
[73, 61, 12] ,
[73, 61, 13] ,
[73, 61, 14] ,
[73, 61, 15] ,
[73, 61, 16] ,
[73, 61, 17] ,
[73, 61, 18] ,
[73, 61, 19] ,
[73, 61, 20] ,
[73, 61, 21] ,
[73, 61, 22] ,
[73, 61, 23] ,
[73, 61, 24] ,
[73, 61, 25] ,
[73, 61, 26] ,
[73, 61, 27] ,
[73, 61, 28] ,
[73, 61, 29] ,
[73, 61, 30] ,
[73, 61, 31] ,
[73, 61, 32] ,
[73, 61, 33] ,
[73, 61, 34] ,
[73, 61, 35] ,
[73, 61, 36] ,
[73, 61, 37] ,
[73, 61, 38] ,
[73, 61, 39] ,
[73, 61, 40] ,
[73, 61, 41] ,
[73, 61, 42] ,
[73, 61, 43] ,
[73, 61, 44] ,
[73, 61, 45] ,
[73, 61, 46] ,
[73, 61, 47] ,
[73, 61, 48] ,
[73, 61, 49] ,
[73, 61, 50] ,
[73, 61, 51] ,
[73, 61, 52] ,
[73, 61, 53] ,
[73, 61, 54] ,
[73, 61, 55] ,
[73, 61, 56] ,
[73, 61, 57] ,
[73, 61, 58] ,
[73, 61, 59] ,
[73, 61, 60] ,
[73, 61, 61] ,
[73, 61, 62] ,
[73, 61, 63] ,
[73, 61, 64] ,
[73, 61, 65] ,
[73, 61, 66] ,
[73, 61, 67] ,
[73, 61, 68] ,
[73, 61, 69] ,
[73, 61, 70] ,
[73, 61, 71] ,
[73, 61, 72] ,
[73, 61, 73] ,
[73, 61, 74] ,
[73, 61, 75] ,
[73, 61, 76] ,
[73, 61, 77] ,
[73, 61, 78] ,
[73, 61, 79] ,
[73, 62, 1] ,
[73, 62, 2] ,
[73, 62, 3] ,
[73, 62, 4] ,
[73, 62, 5] ,
[73, 62, 6] ,
[73, 62, 7] ,
[73, 62, 8] ,
[73, 62, 9] ,
[73, 62, 10] ,
[73, 62, 11] ,
[73, 62, 12] ,
[73, 62, 13] ,
[73, 62, 14] ,
[73, 62, 15] ,
[73, 62, 16] ,
[73, 62, 17] ,
[73, 62, 18] ,
[73, 62, 19] ,
[73, 62, 20] ,
[73, 62, 21] ,
[73, 62, 22] ,
[73, 62, 23] ,
[73, 62, 24] ,
[73, 62, 25] ,
[73, 62, 26] ,
[73, 62, 27] ,
[73, 62, 28] ,
[73, 62, 29] ,
[73, 62, 30] ,
[73, 62, 31] ,
[73, 62, 32] ,
[73, 62, 33] ,
[73, 62, 34] ,
[73, 62, 35] ,
[73, 62, 36] ,
[73, 62, 37] ,
[73, 62, 38] ,
[73, 62, 39] ,
[73, 62, 40] ,
[73, 62, 41] ,
[73, 62, 42] ,
[73, 62, 43] ,
[73, 62, 44] ,
[73, 62, 45] ,
[73, 62, 46] ,
[73, 62, 47] ,
[73, 62, 48] ,
[73, 62, 49] ,
[73, 62, 50] ,
[73, 62, 51] ,
[73, 62, 52] ,
[73, 62, 53] ,
[73, 62, 54] ,
[73, 62, 55] ,
[73, 62, 56] ,
[73, 62, 57] ,
[73, 62, 58] ,
[73, 62, 59] ,
[73, 62, 60] ,
[73, 62, 61] ,
[73, 62, 62] ,
[73, 62, 63] ,
[73, 62, 64] ,
[73, 62, 65] ,
[73, 62, 66] ,
[73, 62, 67] ,
[73, 62, 68] ,
[73, 62, 69] ,
[73, 62, 70] ,
[73, 62, 71] ,
[73, 62, 72] ,
[73, 62, 73] ,
[73, 62, 74] ,
[73, 62, 75] ,
[73, 62, 76] ,
[73, 62, 77] ,
[73, 62, 78] ,
[73, 62, 79] ,
[73, 63, 1] ,
[73, 63, 2] ,
[73, 63, 3] ,
[73, 63, 4] ,
[73, 63, 5] ,
[73, 63, 6] ,
[73, 63, 7] ,
[73, 63, 8] ,
[73, 63, 9] ,
[73, 63, 10] ,
[73, 63, 11] ,
[73, 63, 12] ,
[73, 63, 13] ,
[73, 63, 14] ,
[73, 63, 15] ,
[73, 63, 16] ,
[73, 63, 17] ,
[73, 63, 18] ,
[73, 63, 19] ,
[73, 63, 20] ,
[73, 63, 21] ,
[73, 63, 22] ,
[73, 63, 23] ,
[73, 63, 24] ,
[73, 63, 25] ,
[73, 63, 26] ,
[73, 63, 27] ,
[73, 63, 28] ,
[73, 63, 29] ,
[73, 63, 30] ,
[73, 63, 31] ,
[73, 63, 32] ,
[73, 63, 33] ,
[73, 63, 34] ,
[73, 63, 35] ,
[73, 63, 36] ,
[73, 63, 37] ,
[73, 63, 38] ,
[73, 63, 39] ,
[73, 63, 40] ,
[73, 63, 41] ,
[73, 63, 42] ,
[73, 63, 43] ,
[73, 63, 44] ,
[73, 63, 45] ,
[73, 63, 46] ,
[73, 63, 47] ,
[73, 63, 48] ,
[73, 63, 49] ,
[73, 63, 50] ,
[73, 63, 51] ,
[73, 63, 52] ,
[73, 63, 53] ,
[73, 63, 54] ,
[73, 63, 55] ,
[73, 63, 56] ,
[73, 63, 57] ,
[73, 63, 58] ,
[73, 63, 59] ,
[73, 63, 60] ,
[73, 63, 61] ,
[73, 63, 62] ,
[73, 63, 63] ,
[73, 63, 64] ,
[73, 63, 65] ,
[73, 63, 66] ,
[73, 63, 67] ,
[73, 63, 68] ,
[73, 63, 69] ,
[73, 63, 70] ,
[73, 63, 71] ,
[73, 63, 72] ,
[73, 63, 73] ,
[73, 63, 74] ,
[73, 63, 75] ,
[73, 63, 76] ,
[73, 63, 77] ,
[73, 63, 78] ,
[73, 63, 79] ,
[73, 64, 1] ,
[73, 64, 2] ,
[73, 64, 3] ,
[73, 64, 4] ,
[73, 64, 5] ,
[73, 64, 6] ,
[73, 64, 7] ,
[73, 64, 8] ,
[73, 64, 9] ,
[73, 64, 10] ,
[73, 64, 11] ,
[73, 64, 12] ,
[73, 64, 13] ,
[73, 64, 14] ,
[73, 64, 15] ,
[73, 64, 16] ,
[73, 64, 17] ,
[73, 64, 18] ,
[73, 64, 19] ,
[73, 64, 20] ,
[73, 64, 21] ,
[73, 64, 22] ,
[73, 64, 23] ,
[73, 64, 24] ,
[73, 64, 25] ,
[73, 64, 26] ,
[73, 64, 27] ,
[73, 64, 28] ,
[73, 64, 29] ,
[73, 64, 30] ,
[73, 64, 31] ,
[73, 64, 32] ,
[73, 64, 33] ,
[73, 64, 34] ,
[73, 64, 35] ,
[73, 64, 36] ,
[73, 64, 37] ,
[73, 64, 38] ,
[73, 64, 39] ,
[73, 64, 40] ,
[73, 64, 41] ,
[73, 64, 42] ,
[73, 64, 43] ,
[73, 64, 44] ,
[73, 64, 45] ,
[73, 64, 46] ,
[73, 64, 47] ,
[73, 64, 48] ,
[73, 64, 49] ,
[73, 64, 50] ,
[73, 64, 51] ,
[73, 64, 52] ,
[73, 64, 53] ,
[73, 64, 54] ,
[73, 64, 55] ,
[73, 64, 56] ,
[73, 64, 57] ,
[73, 64, 58] ,
[73, 64, 59] ,
[73, 64, 60] ,
[73, 64, 61] ,
[73, 64, 62] ,
[73, 64, 63] ,
[73, 64, 64] ,
[73, 64, 65] ,
[73, 64, 66] ,
[73, 64, 67] ,
[73, 64, 68] ,
[73, 64, 69] ,
[73, 64, 70] ,
[73, 64, 71] ,
[73, 64, 72] ,
[73, 64, 73] ,
[73, 64, 74] ,
[73, 64, 75] ,
[73, 64, 76] ,
[73, 64, 77] ,
[73, 64, 78] ,
[73, 64, 79] ,
[73, 65, 1] ,
[73, 65, 2] ,
[73, 65, 3] ,
[73, 65, 4] ,
[73, 65, 5] ,
[73, 65, 6] ,
[73, 65, 7] ,
[73, 65, 8] ,
[73, 65, 9] ,
[73, 65, 10] ,
[73, 65, 11] ,
[73, 65, 12] ,
[73, 65, 13] ,
[73, 65, 14] ,
[73, 65, 15] ,
[73, 65, 16] ,
[73, 65, 17] ,
[73, 65, 18] ,
[73, 65, 19] ,
[73, 65, 20] ,
[73, 65, 21] ,
[73, 65, 22] ,
[73, 65, 23] ,
[73, 65, 24] ,
[73, 65, 25] ,
[73, 65, 26] ,
[73, 65, 27] ,
[73, 65, 28] ,
[73, 65, 29] ,
[73, 65, 30] ,
[73, 65, 31] ,
[73, 65, 32] ,
[73, 65, 33] ,
[73, 65, 34] ,
[73, 65, 35] ,
[73, 65, 36] ,
[73, 65, 37] ,
[73, 65, 38] ,
[73, 65, 39] ,
[73, 65, 40] ,
[73, 65, 41] ,
[73, 65, 42] ,
[73, 65, 43] ,
[73, 65, 44] ,
[73, 65, 45] ,
[73, 65, 46] ,
[73, 65, 47] ,
[73, 65, 48] ,
[73, 65, 49] ,
[73, 65, 50] ,
[73, 65, 51] ,
[73, 65, 52] ,
[73, 65, 53] ,
[73, 65, 54] ,
[73, 65, 55] ,
[73, 65, 56] ,
[73, 65, 57] ,
[73, 65, 58] ,
[73, 65, 59] ,
[73, 65, 60] ,
[73, 65, 61] ,
[73, 65, 62] ,
[73, 65, 63] ,
[73, 65, 64] ,
[73, 65, 65] ,
[73, 65, 66] ,
[73, 65, 67] ,
[73, 65, 68] ,
[73, 65, 69] ,
[73, 65, 70] ,
[73, 65, 71] ,
[73, 65, 72] ,
[73, 65, 73] ,
[73, 65, 74] ,
[73, 65, 75] ,
[73, 65, 76] ,
[73, 65, 77] ,
[73, 65, 78] ,
[73, 65, 79] ,
[73, 66, 1] ,
[73, 66, 2] ,
[73, 66, 3] ,
[73, 66, 4] ,
[73, 66, 5] ,
[73, 66, 6] ,
[73, 66, 7] ,
[73, 66, 8] ,
[73, 66, 9] ,
[73, 66, 10] ,
[73, 66, 11] ,
[73, 66, 12] ,
[73, 66, 13] ,
[73, 66, 14] ,
[73, 66, 15] ,
[73, 66, 16] ,
[73, 66, 17] ,
[73, 66, 18] ,
[73, 66, 19] ,
[73, 66, 20] ,
[73, 66, 21] ,
[73, 66, 22] ,
[73, 66, 23] ,
[73, 66, 24] ,
[73, 66, 25] ,
[73, 66, 26] ,
[73, 66, 27] ,
[73, 66, 28] ,
[73, 66, 29] ,
[73, 66, 30] ,
[73, 66, 31] ,
[73, 66, 32] ,
[73, 66, 33] ,
[73, 66, 34] ,
[73, 66, 35] ,
[73, 66, 36] ,
[73, 66, 37] ,
[73, 66, 38] ,
[73, 66, 39] ,
[73, 66, 40] ,
[73, 66, 41] ,
[73, 66, 42] ,
[73, 66, 43] ,
[73, 66, 44] ,
[73, 66, 45] ,
[73, 66, 46] ,
[73, 66, 47] ,
[73, 66, 48] ,
[73, 66, 49] ,
[73, 66, 50] ,
[73, 66, 51] ,
[73, 66, 52] ,
[73, 66, 53] ,
[73, 66, 54] ,
[73, 66, 55] ,
[73, 66, 56] ,
[73, 66, 57] ,
[73, 66, 58] ,
[73, 66, 59] ,
[73, 66, 60] ,
[73, 66, 61] ,
[73, 66, 62] ,
[73, 66, 63] ,
[73, 66, 64] ,
[73, 66, 65] ,
[73, 66, 66] ,
[73, 66, 67] ,
[73, 66, 68] ,
[73, 66, 69] ,
[73, 66, 70] ,
[73, 66, 71] ,
[73, 66, 72] ,
[73, 66, 73] ,
[73, 66, 74] ,
[73, 66, 75] ,
[73, 66, 76] ,
[73, 66, 77] ,
[73, 66, 78] ,
[73, 66, 79] ,
[73, 67, 1] ,
[73, 67, 2] ,
[73, 67, 3] ,
[73, 67, 4] ,
[73, 67, 5] ,
[73, 67, 6] ,
[73, 67, 7] ,
[73, 67, 8] ,
[73, 67, 9] ,
[73, 67, 10] ,
[73, 67, 11] ,
[73, 67, 12] ,
[73, 67, 13] ,
[73, 67, 14] ,
[73, 67, 15] ,
[73, 67, 16] ,
[73, 67, 17] ,
[73, 67, 18] ,
[73, 67, 19] ,
[73, 67, 20] ,
[73, 67, 21] ,
[73, 67, 22] ,
[73, 67, 23] ,
[73, 67, 24] ,
[73, 67, 25] ,
[73, 67, 26] ,
[73, 67, 27] ,
[73, 67, 28] ,
[73, 67, 29] ,
[73, 67, 30] ,
[73, 67, 31] ,
[73, 67, 32] ,
[73, 67, 33] ,
[73, 67, 34] ,
[73, 67, 35] ,
[73, 67, 36] ,
[73, 67, 37] ,
[73, 67, 38] ,
[73, 67, 39] ,
[73, 67, 40] ,
[73, 67, 41] ,
[73, 67, 42] ,
[73, 67, 43] ,
[73, 67, 44] ,
[73, 67, 45] ,
[73, 67, 46] ,
[73, 67, 47] ,
[73, 67, 48] ,
[73, 67, 49] ,
[73, 67, 50] ,
[73, 67, 51] ,
[73, 67, 52] ,
[73, 67, 53] ,
[73, 67, 54] ,
[73, 67, 55] ,
[73, 67, 56] ,
[73, 67, 57] ,
[73, 67, 58] ,
[73, 67, 59] ,
[73, 67, 60] ,
[73, 67, 61] ,
[73, 67, 62] ,
[73, 67, 63] ,
[73, 67, 64] ,
[73, 67, 65] ,
[73, 67, 66] ,
[73, 67, 67] ,
[73, 67, 68] ,
[73, 67, 69] ,
[73, 67, 70] ,
[73, 67, 71] ,
[73, 67, 72] ,
[73, 67, 73] ,
[73, 67, 74] ,
[73, 67, 75] ,
[73, 67, 76] ,
[73, 67, 77] ,
[73, 67, 78] ,
[73, 67, 79] ,
[73, 68, 1] ,
[73, 68, 2] ,
[73, 68, 3] ,
[73, 68, 4] ,
[73, 68, 5] ,
[73, 68, 6] ,
[73, 68, 7] ,
[73, 68, 8] ,
[73, 68, 9] ,
[73, 68, 10] ,
[73, 68, 11] ,
[73, 68, 12] ,
[73, 68, 13] ,
[73, 68, 14] ,
[73, 68, 15] ,
[73, 68, 16] ,
[73, 68, 17] ,
[73, 68, 18] ,
[73, 68, 19] ,
[73, 68, 20] ,
[73, 68, 21] ,
[73, 68, 22] ,
[73, 68, 23] ,
[73, 68, 24] ,
[73, 68, 25] ,
[73, 68, 26] ,
[73, 68, 27] ,
[73, 68, 28] ,
[73, 68, 29] ,
[73, 68, 30] ,
[73, 68, 31] ,
[73, 68, 32] ,
[73, 68, 33] ,
[73, 68, 34] ,
[73, 68, 35] ,
[73, 68, 36] ,
[73, 68, 37] ,
[73, 68, 38] ,
[73, 68, 39] ,
[73, 68, 40] ,
[73, 68, 41] ,
[73, 68, 42] ,
[73, 68, 43] ,
[73, 68, 44] ,
[73, 68, 45] ,
[73, 68, 46] ,
[73, 68, 47] ,
[73, 68, 48] ,
[73, 68, 49] ,
[73, 68, 50] ,
[73, 68, 51] ,
[73, 68, 52] ,
[73, 68, 53] ,
[73, 68, 54] ,
[73, 68, 55] ,
[73, 68, 56] ,
[73, 68, 57] ,
[73, 68, 58] ,
[73, 68, 59] ,
[73, 68, 60] ,
[73, 68, 61] ,
[73, 68, 62] ,
[73, 68, 63] ,
[73, 68, 64] ,
[73, 68, 65] ,
[73, 68, 66] ,
[73, 68, 67] ,
[73, 68, 68] ,
[73, 68, 69] ,
[73, 68, 70] ,
[73, 68, 71] ,
[73, 68, 72] ,
[73, 68, 73] ,
[73, 68, 74] ,
[73, 68, 75] ,
[73, 68, 76] ,
[73, 68, 77] ,
[73, 68, 78] ,
[73, 68, 79] ,
[73, 69, 1] ,
[73, 69, 2] ,
[73, 69, 3] ,
[73, 69, 4] ,
[73, 69, 5] ,
[73, 69, 6] ,
[73, 69, 7] ,
[73, 69, 8] ,
[73, 69, 9] ,
[73, 69, 10] ,
[73, 69, 11] ,
[73, 69, 12] ,
[73, 69, 13] ,
[73, 69, 14] ,
[73, 69, 15] ,
[73, 69, 16] ,
[73, 69, 17] ,
[73, 69, 18] ,
[73, 69, 19] ,
[73, 69, 20] ,
[73, 69, 21] ,
[73, 69, 22] ,
[73, 69, 23] ,
[73, 69, 24] ,
[73, 69, 25] ,
[73, 69, 26] ,
[73, 69, 27] ,
[73, 69, 28] ,
[73, 69, 29] ,
[73, 69, 30] ,
[73, 69, 31] ,
[73, 69, 32] ,
[73, 69, 33] ,
[73, 69, 34] ,
[73, 69, 35] ,
[73, 69, 36] ,
[73, 69, 37] ,
[73, 69, 38] ,
[73, 69, 39] ,
[73, 69, 40] ,
[73, 69, 41] ,
[73, 69, 42] ,
[73, 69, 43] ,
[73, 69, 44] ,
[73, 69, 45] ,
[73, 69, 46] ,
[73, 69, 47] ,
[73, 69, 48] ,
[73, 69, 49] ,
[73, 69, 50] ,
[73, 69, 51] ,
[73, 69, 52] ,
[73, 69, 53] ,
[73, 69, 54] ,
[73, 69, 55] ,
[73, 69, 56] ,
[73, 69, 57] ,
[73, 69, 58] ,
[73, 69, 59] ,
[73, 69, 60] ,
[73, 69, 61] ,
[73, 69, 62] ,
[73, 69, 63] ,
[73, 69, 64] ,
[73, 69, 65] ,
[73, 69, 66] ,
[73, 69, 67] ,
[73, 69, 68] ,
[73, 69, 69] ,
[73, 69, 70] ,
[73, 69, 71] ,
[73, 69, 72] ,
[73, 69, 73] ,
[73, 69, 74] ,
[73, 69, 75] ,
[73, 69, 76] ,
[73, 69, 77] ,
[73, 69, 78] ,
[73, 69, 79] ,
[74, 48, 1] ,
[74, 48, 2] ,
[74, 48, 3] ,
[74, 48, 4] ,
[74, 48, 5] ,
[74, 48, 6] ,
[74, 48, 7] ,
[74, 48, 8] ,
[74, 48, 9] ,
[74, 48, 10] ,
[74, 48, 11] ,
[74, 48, 12] ,
[74, 48, 13]
    ]
#     for s_seat1 in range(52,77):
#         for s_seat2 in range(48,s_seat1-3):
#             for loop in range(1,80):
#                 a = [s_seat1 , s_seat2 , loop]
#                 zong_s_p.append(a)
    
    path = 'imp_chanfen_FSE_9R_my.txt'
    data = []
    with open(path , 'r') as f:
        for line in f.readlines():
            if line != '\n':
                data.append(line[0:64])
    
    key_var = []
    for i in range(len(data)//2):
        shang = int(data[2*i][::-1],2)
        xia = int(data[2*i+1][::-1],2)
        temp1 = return_key_find_shang(shang)
        temp2 = return_key_find_xia(xia)
        if (temp1 not in key_var) or (temp2 not in key_var):
            key_var.append(temp1)
            key_var.append(temp2)
            
    key_var = []
    asdfa = []
    for i in range(len(data)//2):
        shang = int(data[2*i][::-1],2)
        xia = int(data[2*i+1][::-1],2)
        temp1 = return_key_find_shang(shang)
        temp2 = return_key_find_xia(xia)
        temp = []
        for u in temp1:
            temp.append(temp1[u])
        for v in temp2:
            temp.append(temp2[v])       
        if temp not in asdfa:
            asdfa.append(temp)
            key_var.append(temp1)
            key_var.append(temp2)
#     print(len(asdfa))
    zong_key_var = []
    for i in range(9):
        zong_key_var.append(key_var)
    
    for i in range(len(zong_s_p)):
        pool.apply_async(aleifjadklf1, (zong_key_var[i%9],zong_s_p[i],lujing,path1[i%9],))   
 
        # 阻塞式，先执行完子进程，再执行主进程
        # pool.apply(func, (msg, ))   
 
    print("Mark~ Mark~ Mark~~~~~~~~~~~~~~~~~~~~~~")
    # 调用join之前，先调用close函数，否则会出错。
    pool.close()
    # 执行完close后不会有新的进程加入到pool,join函数等待所有子进程结束
    pool.join()   
    print("Sub-process(es) done.")
# path1 = 'check.txt'
# lujing = 'new_check'
# aleifjadklf(key_var,zong_s_p,lujing,path1)
