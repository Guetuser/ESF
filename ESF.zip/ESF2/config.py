# Path to Sagemath executable
# PATH_SAGE = '/usr/local/bin/sage'
PATH_SAGE = '/usr/bin/sage'
TEMP_DIR = 'temp'
